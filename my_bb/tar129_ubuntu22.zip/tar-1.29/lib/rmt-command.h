#ifndef DEFAULT_RMT_COMMAND
# define DEFAULT_RMT_COMMAND "/opt/tar-129/libexec/rmt"
#endif
