#ifndef DEFAULT_RMT_COMMAND
# define DEFAULT_RMT_COMMAND "/opt/tar129/libexec/rmt"
#endif
